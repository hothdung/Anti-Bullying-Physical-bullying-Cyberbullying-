//
//  InterfaceController.swift
//  AudioAppTest WatchKit Extension
//
//

import WatchKit
import Foundation
import AVFoundation


class InterfaceController: WKInterfaceController, AVAudioRecorderDelegate, AVAudioPlayerDelegate{
    
    
    @IBOutlet weak var recordBtn: WKInterfaceButton!
    var recordSession: AVAudioSession!
    var audioRecorder: AVAudioRecorder!
    var audioPlayer: AVAudioPlayer!
    var settings = [String : Int]()
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        print("Hello Test")
        recordSession = AVAudioSession.sharedInstance()
        
        if(recordSession.responds(to:#selector(AVAudioSession.requestRecordPermission(_:)))){
        // configure audio settings
            AVAudioSession.sharedInstance().requestRecordPermission({(granted: Bool) -> Void in
                if granted{
                    print("Recording granted!")
                    
                    do{
                        try self.recordSession.setCategory(.playAndRecord,mode: .default, options: [])
                        try self.recordSession.setActive(true)
                    }catch{
                        print("Audio session could not be set!")
                    }
                }else{
                    print("Recording not granted!")
                }
            })
        }
        
        settings = [AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
        AVSampleRateKey: 12000,
        AVNumberOfChannelsKey: 1,
        AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    func getDocumentsDirectory()-> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentDirectory = paths[0]
        return documentDirectory
    }
    
    func getAudioURL() -> URL {
        let filename = NSUUID().uuidString+"recording.m4a"
        return getDocumentsDirectory().appendingPathComponent(filename)
    }
    
    func startRecording(){
  
        do{
            audioRecorder = try AVAudioRecorder(url:self.getAudioURL(),settings:settings)
            audioRecorder.delegate = self
            audioRecorder.record(forDuration: 15)
        }catch{
            finishRecording(success: false)
        }
        
    }
    
    func finishRecording(success: Bool){
        audioRecorder.stop()
        if success{
            print("Recorded successfully!")
        }else{
            audioRecorder = nil
            print("Recording failed!")
        }
        // setting audioRecorder to nil??

    }
    
    @IBAction func recordListener() {
        print("Button clicked!")
               if audioRecorder == nil{
                   self.startRecording()
               }else{
                   self.finishRecording(success: true)
               }
    }
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if !flag{
            finishRecording(success:false)
        }
        print(recorder.url)

    }
    /**
    func preparePlayer(){
        do{
            audioPlayer = try AVAudioPlayer(contentsOf: self.getAudioURL())
            audioPlayer.delegate = self
            audioPlayer.prepareToPlay()
            audioPlayer.volume = 3.0
        }catch{
            if let err = error as Error?{
                print("AVAudioPlayer error: \(err.localizedDescription)")
            }
        }
    }
    */
    
    @IBAction func playPressed() {
        //preparePlayer()
        
        if !audioRecorder.isRecording{
            audioPlayer = try! AVAudioPlayer(contentsOf: audioRecorder.url)
            audioPlayer.prepareToPlay()
            audioPlayer.delegate = self
            audioPlayer.play()
        }
    
    }
}
